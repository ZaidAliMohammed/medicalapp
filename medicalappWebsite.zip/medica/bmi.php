<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />

<script  type="text/javascript" src="includes/js.js"></script>
<link rel="stylesheet" type="text/css" href="includes/css.css">

<script type="text/javascript" src="lib/sweetalert.min.js"></script>
<link rel="stylesheet" type="text/css" href="lib/sweetalert.min.css">

<title>BMI Calculator</title>

</head>


<body>

<div class="title_1">BMI Calculator</div>
<div class="title_33"></div>
  <div id="imperial">
    <label class="sitecolor">Choose:&nbsp;</label><a href="#imperial" style="color:#000; text-decoration:none;" onclick="return show('metric','imperial');">Imperial</br></a>


	  <!-------------------bmi caculator-------------------->
	  <div class="calculation_home">
			  <div class="r1">
		      <div class="R3">
			  <form id="Calculator" name="form" method="post" action="">
	          <div class="R3"> 
			  <label>Gender:</label><input type="radio" name="radio" id="Male_r" value="Male" /><label class="dark">Male</label>
			  <input type="radio" name="radio" id="Female_r" value="Female" /><label class="dark">Female</label>
			  </div>
			  <div class="R3"><label>Weight:</label><input class="bmi" type="text" name="weight_txt" id="weight_id" size="5" /><label class="unbold"><a class="dark">Kg</a></label></div>
			  <div class="R3"><label>Height:</label><input class="bmi1" type="text" name="height_txt" id="height_id"  size="5"/><label class="unbold"><a class="dark">Cm</a></label></div>
			  <DIV class="R2">
			  
			  <input class="cal_home_1"  style="cursor:pointer" type="button" value="CALCULATE" id="cal_bmi" onclick="calculate_m()" /></div>
	  		  </form>
		      </div>
				
		      </div>
              </div>


  </div>

  <div id="metric" style="display:none">
    <label class="sitecolor">Choose:&nbsp;</label><a href="#metric" style="color:#000; text-decoration:none;" onclick="return show('imperial','metric');">Metric</br></a>


	  <!-------------------bmi caculator-------------------->
	  <div class="calculation_home">
			  <div class="r1">
		      <div class="R3">
			  <form id="Calculator1" name="form" method="post" action="">
	          <div class="R3"> 
			  <label>Gender:</label><input type="radio" name="radio" id="Male_r" value="Male" /><label class="dark">Male</label>
			  <input type="radio" name="radio" id="Female_r" value="Female" /><label class="dark">Female</label>
			  </div>
			  <div class="R3"><label>Weight:</label><input class="bmi" type="text" name="weight1_txt" id="weight1_id" size="5" /><label class="unbold"><a class="dark">Pound</a></label></div>
			  <div class="R3"><label>Height:</label><input class="bmi1" type="text" name="height1_txt" id="height1_id"  size="5"/><label class="unbold"><a class="dark">Inch</a></label></div>
			  <DIV class="R2">
			  
			  <input class="cal_home_1"  style="cursor:pointer" type="button" value="CALCULATE" id="cal_bmi1" onclick="calculate_i()" /></div>
	  		  </form>
		      </div>
				
		      </div>
              </div>

  </div>




</body>

</html>