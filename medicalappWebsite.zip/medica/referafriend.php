<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<script type="text/javascript" src="lib/jquery.min.js"></script>

<script type="text/javascript" src="includes/jquery-1.11.3.js"></script>

<link rel="stylesheet" type="text/css" href="includes/css.css">

<script type="text/javascript" src="lib/sweetalert.min.js"></script>
<link rel="stylesheet" type="text/css" href="lib/sweetalert.min.css">
<script type="text/javascript" src="includes/js.js"></script>

<title>Refer a Friend</title>
</head>

<body>
		  <?php
          include 'db/db.php';
          $sql_description="select friends_des from bloodbank_description_f ORDER BY id DESC LIMIT 1 ";
          $res_description=mysqli_query($con,$sql_description);
          $result_description=mysqli_fetch_array($res_description);
		  
		  $sql_picture="select friends_pic from bloodbank_picture_f ORDER BY id DESC LIMIT 3 ";
          $res_picture=mysqli_query($con,$sql_picture);
		  
		  $sql_province="select province from lb_div ORDER BY id ASC ";
          $res_province=mysqli_query($con,$sql_province);
		  
		  $sql_department="select department from lb_div ORDER BY id ASC ";
          $res_department=mysqli_query($con,$sql_department);
		  
		  $sql_state="select state from lb_div ORDER BY id ASC ";
          $res_state=mysqli_query($con,$sql_state);
		  
		  $sql_street="select street from lb_div ORDER BY id ASC ";
          $res_street=mysqli_query($con,$sql_street);

		  $sql_picture_f="select friends_pic from bloodbank_f_picture_f ORDER BY id DESC LIMIT 1 ";
          $res_picture_f=mysqli_query($con,$sql_picture_f);
		  $result_picture_f=mysqli_fetch_array($res_picture_f);
          ?>           








<div class="position_ref" >

<div class="space11"></div>

<div class="titl11">Blood Bank (refer a friend)</div>

<div class="space11"></div>


<div class="description">
<div class="paragh">
<?=$result_description['friends_des']?>
</div>
</div>

<div class="space11"></div>



<div class="position_l_ref" style=" background-color:#fff">


<form id="form_refer" class="alignment_register" name="form_refer" method="post"  action="javascript:void(0)">



<div class="textbox_position"><a style="color:#A6271C; font-size:22px; font-weight:bold;">Friend Name:<span style="color:#red;">*</span></a>
<div class="new_a1r"><input class="textbox_properties1" type="text" name="friendname_id" id="friendname_id"  style="color:#000000; border:3px solid #A6271C; font-size:23px; font-family: AddFont; font-family:'Simplified Arabic'; " /><img class="error_pic" id="friendname_e" height="20" width="20" src="icons/error.png" />
</div></div>



<div class="textbox_position"><a style="color:#A6271C; font-size:22px; font-weight:bold;">Email:<span style="color:#red;">*</span></a>
<div class="new_a1r"><input class="textbox_properties1" type="text" name="email_id" id="email_id"  style="color:#000000; border:3px solid #A6271C; font-size:23px; font-family: AddFont; font-family:'Simplified Arabic'; " /><img class="error_pic" id="email_e" height="20" width="20" src="icons/error.png" />
</div></div>



<div class="textbox_position"><a style="color:#A6271C; font-size:22px; font-weight:bold;">Your Name:<span style="color:#red;">*</span></a>
<div class="new_a1r"><input class="textbox_properties1" type="text" name="yourname_id" id="yourname_id"  style="color:#000000; border:3px solid #A6271C; font-size:23px; font-family: AddFont; font-family:'Simplified Arabic'; " /><img class="error_pic" id="yourname_e" height="20" width="20" src="icons/error.png" />
</div></div>


<div class="notes1">(<span class="notes">*</span> Must be filled)</div>

<div class="submitbox_position_reg">
<input class="submit_style_reg" style="cursor:pointer;  border:3px solid #A6271C; font-size:23px; font-family: AddFont;     height: 36px; font-family:'Times New Roman', Times, serif;" type="submit" name="refer_id" id="refer_id" value="Send" onclick="refer_friend()" />
</div>

</form> 
</div>




  
<div  class="position_r_ref">
<?php
while($result_picture=mysqli_fetch_array($res_picture))
{
?>


<img src="uploads/<?=$result_picture['friends_pic']?>" width="300" height="300" />

<?php
}
?>

</div>  



<div  class="position_s">
<img src="uploads/<?=$result_picture_f['friends_pic']?>" width="1000" height="200" />
</div>

</div>
  

  
  
  




</div>  
  
  


</body>
</html>