-- phpMyAdmin SQL Dump
-- version 4.5.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Nov 18, 2016 at 08:05 AM
-- Server version: 5.7.11
-- PHP Version: 5.6.19

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `medica`
--

-- --------------------------------------------------------

--
-- Table structure for table `bloodbank`
--

CREATE TABLE `bloodbank` (
  `id` int(11) NOT NULL,
  `firstname` text NOT NULL,
  `lastname` text NOT NULL,
  `age` text NOT NULL,
  `contact` text NOT NULL,
  `province` text NOT NULL,
  `department` text NOT NULL,
  `state` text NOT NULL,
  `street` text NOT NULL,
  `blood` varchar(255) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `bloodbank`
--

INSERT INTO `bloodbank` (`id`, `firstname`, `lastname`, `age`, `contact`, `province`, `department`, `state`, `street`, `blood`) VALUES
(31, 'aaa', 'aaaaaa', '2535', '2352323', 'Beqaa', 'Mazraa', 'Abbassieh', 'Bliss Street', 'B+'),
(23, 'c', 'd', '2', '3333333', 'Beqaa', 'Bachoura', 'Aaytit', 'Rue Spears', 'AB-'),
(30, 'll', 'lllll', '7854', '463634', 'Nabatiyeh', 'Achrafieh', 'Abboudieh', 'Bliss Street', 'O+'),
(25, 'fff', 'fff', '34324', '32234324', 'Nabatiyeh', 'Moussaitbeh', 'Aaray', 'Rue John Kennedy', 'AB-'),
(26, 'cccc', 'ccccccc', '3323', '2523532', 'Nabatiyeh', 'Medawar', 'Abbassieh', 'Bliss Street', 'AB-'),
(27, 'rte', 'tewew', '2342', '2342342', 'Beqaa', 'Moussaitbeh', 'Abbassieh', 'Bliss Street', 'A+'),
(28, 'tt', 'ttttt', '5345', '52353252', 'Beqaa', 'Achrafieh', 'Abbassieh', 'Rue John Kennedy', 'O+'),
(29, 'k', 'kkk', '88', '88888', 'South', 'Moussaitbeh', 'Aaytit', 'Rue Madame Curie', 'B+'),
(32, 'JJ', 'JJJJ', '4563', '63456356', 'Beqaa', 'Achrafieh', 'Abbassieh', 'Rue Spears', 'AB+'),
(33, 'tt', 'tttt', '22', '2222', 'Beirut', 'Mazraa', 'Aaray', 'Rue Madame Curie', 'B-');

-- --------------------------------------------------------

--
-- Table structure for table `bloodbank_description_d`
--

CREATE TABLE `bloodbank_description_d` (
  `id` int(11) NOT NULL,
  `donors_des` text NOT NULL,
  `donors_des_french` text NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `bloodbank_description_d`
--

INSERT INTO `bloodbank_description_d` (`id`, `donors_des`, `donors_des_french`) VALUES
(1, 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.', 'french   Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.');

-- --------------------------------------------------------

--
-- Table structure for table `bloodbank_description_f`
--

CREATE TABLE `bloodbank_description_f` (
  `id` int(11) NOT NULL,
  `friends_des` text NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `bloodbank_description_f`
--

INSERT INTO `bloodbank_description_f` (`id`, `friends_des`) VALUES
(1, 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.');

-- --------------------------------------------------------

--
-- Table structure for table `bloodbank_description_h`
--

CREATE TABLE `bloodbank_description_h` (
  `id` int(11) NOT NULL,
  `hospitals_des` text NOT NULL,
  `hospitals_des_french` text NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `bloodbank_description_h`
--

INSERT INTO `bloodbank_description_h` (`id`, `hospitals_des`, `hospitals_des_french`) VALUES
(1, 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.', 'french ----Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.');

-- --------------------------------------------------------

--
-- Table structure for table `bloodbank_friends`
--

CREATE TABLE `bloodbank_friends` (
  `id` int(11) NOT NULL,
  `yourname` varchar(255) NOT NULL,
  `friendname` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `bloodbank_friends`
--

INSERT INTO `bloodbank_friends` (`id`, `yourname`, `friendname`, `email`) VALUES
(1, 'rr', 'ffffff', 'gg@gmail.vv'),
(2, 'test1', 'test', 'gg@gmail.vv');

-- --------------------------------------------------------

--
-- Table structure for table `bloodbank_f_picture_d`
--

CREATE TABLE `bloodbank_f_picture_d` (
  `id` int(11) NOT NULL,
  `donors_pic` varchar(255) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `bloodbank_f_picture_d`
--

INSERT INTO `bloodbank_f_picture_d` (`id`, `donors_pic`) VALUES
(1, 'BloodBank24.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `bloodbank_f_picture_f`
--

CREATE TABLE `bloodbank_f_picture_f` (
  `id` int(11) NOT NULL,
  `friends_pic` varchar(255) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `bloodbank_f_picture_f`
--

INSERT INTO `bloodbank_f_picture_f` (`id`, `friends_pic`) VALUES
(1, 'BloodBank24.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `bloodbank_f_picture_h`
--

CREATE TABLE `bloodbank_f_picture_h` (
  `id` int(11) NOT NULL,
  `hospitals_pic` varchar(255) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `bloodbank_f_picture_h`
--

INSERT INTO `bloodbank_f_picture_h` (`id`, `hospitals_pic`) VALUES
(1, 'BloodBank24.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `bloodbank_picture_d`
--

CREATE TABLE `bloodbank_picture_d` (
  `id` int(11) NOT NULL,
  `donors_pic` varchar(255) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `bloodbank_picture_d`
--

INSERT INTO `bloodbank_picture_d` (`id`, `donors_pic`) VALUES
(1, 'BloodBank4.png'),
(2, 'BloodBank5.png'),
(3, 'BloodBank6.png');

-- --------------------------------------------------------

--
-- Table structure for table `bloodbank_picture_f`
--

CREATE TABLE `bloodbank_picture_f` (
  `id` int(11) NOT NULL,
  `friends_pic` varchar(255) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `bloodbank_picture_f`
--

INSERT INTO `bloodbank_picture_f` (`id`, `friends_pic`) VALUES
(4, 'referafriend.png');

-- --------------------------------------------------------

--
-- Table structure for table `bloodbank_picture_h`
--

CREATE TABLE `bloodbank_picture_h` (
  `id` int(11) NOT NULL,
  `hospitals_pic` varchar(255) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `bloodbank_picture_h`
--

INSERT INTO `bloodbank_picture_h` (`id`, `hospitals_pic`) VALUES
(1, 'BloodBank1.png');

-- --------------------------------------------------------

--
-- Table structure for table `convertor`
--

CREATE TABLE `convertor` (
  `id` int(11) NOT NULL,
  `con_pic` varchar(255) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `convertor`
--

INSERT INTO `convertor` (`id`, `con_pic`) VALUES
(1, '1.png'),
(2, '2.png'),
(3, '3.png');

-- --------------------------------------------------------

--
-- Table structure for table `lb_div`
--

CREATE TABLE `lb_div` (
  `id` int(11) NOT NULL,
  `province` varchar(255) NOT NULL,
  `department` varchar(255) NOT NULL,
  `state` varchar(255) NOT NULL,
  `street` varchar(255) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `lb_div`
--

INSERT INTO `lb_div` (`id`, `province`, `department`, `state`, `street`) VALUES
(19, 'South', 'Moussaitbeh', 'Abboudieh', 'Rue Spears'),
(18, 'North', 'Medawar', 'Abbassieh', 'Rue Jeanne d\'Arc'),
(17, 'Nabatiyeh', 'Mazraa', 'Abadiyeh', 'Rue John Kennedy'),
(16, 'Beqaa', 'Bachoura', 'Aaytit', 'Rue Madame Curie'),
(15, 'Beirut', 'Achrafieh', 'Aaray', 'Bliss Street');

-- --------------------------------------------------------

--
-- Table structure for table `picture_tips`
--

CREATE TABLE `picture_tips` (
  `id` int(11) NOT NULL,
  `tips_pic` varchar(255) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `picture_tips`
--

INSERT INTO `picture_tips` (`id`, `tips_pic`) VALUES
(1, 'tips.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `tips`
--

CREATE TABLE `tips` (
  `id` int(11) NOT NULL,
  `title` text NOT NULL,
  `title_fr` text NOT NULL,
  `details` text NOT NULL,
  `details_fr` text NOT NULL,
  `type` varchar(255) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tips`
--

INSERT INTO `tips` (`id`, `title`, `title_fr`, `details`, `details_fr`, `type`) VALUES
(11, 'cxx', 'frf f rfrf fr', 'xcvxcv vxcv xc v', 'frf f rfrf frfrf f rfrf frfrf f rfrf fr', 'type1'),
(7, 'rrrr', 'frf f rfrf fr', 'rrtrtr r trt rt r tr tr t', 'frf f rfrf frvfrf f rfrf frfrf f rfrf fr', 'type1'),
(8, 'hhj', 'frf f rfrf fr', 'hj hhjhj hj h jhhj h hj', 'frf f rfrf frfrf f rfrf frfrf f rfrf fr', 'type2'),
(9, 'ghf', 'frf f rfrf fr', 'ghjgh hg ghj ghj ghj g jgxc zc', 'frf f rfrf frfrf f rfrf frfrf f rfrf frfrf f rfrf frfrf f rfrf frfrf f rfrf frfrf f rfrf frfrf f rfrf frfrf f rfrf frfrf f rfrf frfrf f rfrf frfrf f rfrf frfrf f rfrf frfrf f rfrf frfrf f rfrf frfrf f rfrf frfrf f rfrf frfrf f rfrf frfrf f rfrf fr', 'type1'),
(10, 'kkk', 'frf f rfrf fr', 'kkkjk k k kk k k k kk ', 'frf f rfrf fr', 'type1'),
(5, 'ggggg', 'frf f rfrf fr', 'ggg g g g g gg g g gg  g dsfdsf sddfsd fsd fsfsfsfs', 'frf f rfrf frfrf f rfrf frfrf f rfrf frfrf f rfrf fr', 'type1'),
(6, 'saga', 'frf f rfrf fr', 'adfasdf fafasfasdff  asfafas  asfa aasda', 'frf f rfrf frfrf f rfrf frfrf f rfrf frfrf f rfrf frfrf f rfrf frfrf f rfrf frfrf f rfrf frfrf f rfrf frfrf f rfrf frfrf f rfrf frfrf f rfrf frfrf f rfrf frfrf f rfrf frfrf f rfrf frfrf f rfrf frfrf f rfrf frfrf f rfrf frfrf f rfrf frfrf f rfrf frfrf f rfrf frfrf f rfrf frfrf f rfrf frfrf f rfrf frfrf f rfrf frfrf f rfrf frfrf f rfrf fr', 'type2');

-- --------------------------------------------------------

--
-- Table structure for table `tips_description`
--

CREATE TABLE `tips_description` (
  `id` int(11) NOT NULL,
  `tips_des` text NOT NULL,
  `tips_des_french` text NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tips_description`
--

INSERT INTO `tips_description` (`id`, `tips_des`, `tips_des_french`) VALUES
(1, 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.', 'french -----Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.');

-- --------------------------------------------------------

--
-- Table structure for table `tips_type`
--

CREATE TABLE `tips_type` (
  `id` int(11) NOT NULL,
  `type` text NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tips_type`
--

INSERT INTO `tips_type` (`id`, `type`) VALUES
(1, 'type1'),
(2, 'type2');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `bloodbank`
--
ALTER TABLE `bloodbank`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `bloodbank_description_d`
--
ALTER TABLE `bloodbank_description_d`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `bloodbank_description_f`
--
ALTER TABLE `bloodbank_description_f`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `bloodbank_description_h`
--
ALTER TABLE `bloodbank_description_h`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `bloodbank_friends`
--
ALTER TABLE `bloodbank_friends`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `bloodbank_f_picture_d`
--
ALTER TABLE `bloodbank_f_picture_d`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `bloodbank_f_picture_f`
--
ALTER TABLE `bloodbank_f_picture_f`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `bloodbank_f_picture_h`
--
ALTER TABLE `bloodbank_f_picture_h`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `bloodbank_picture_d`
--
ALTER TABLE `bloodbank_picture_d`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `bloodbank_picture_f`
--
ALTER TABLE `bloodbank_picture_f`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `bloodbank_picture_h`
--
ALTER TABLE `bloodbank_picture_h`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `convertor`
--
ALTER TABLE `convertor`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `lb_div`
--
ALTER TABLE `lb_div`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `picture_tips`
--
ALTER TABLE `picture_tips`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tips`
--
ALTER TABLE `tips`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tips_description`
--
ALTER TABLE `tips_description`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tips_type`
--
ALTER TABLE `tips_type`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `bloodbank`
--
ALTER TABLE `bloodbank`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=34;
--
-- AUTO_INCREMENT for table `bloodbank_description_d`
--
ALTER TABLE `bloodbank_description_d`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `bloodbank_description_f`
--
ALTER TABLE `bloodbank_description_f`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `bloodbank_description_h`
--
ALTER TABLE `bloodbank_description_h`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `bloodbank_friends`
--
ALTER TABLE `bloodbank_friends`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `bloodbank_f_picture_d`
--
ALTER TABLE `bloodbank_f_picture_d`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `bloodbank_f_picture_f`
--
ALTER TABLE `bloodbank_f_picture_f`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `bloodbank_f_picture_h`
--
ALTER TABLE `bloodbank_f_picture_h`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `bloodbank_picture_d`
--
ALTER TABLE `bloodbank_picture_d`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `bloodbank_picture_f`
--
ALTER TABLE `bloodbank_picture_f`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `bloodbank_picture_h`
--
ALTER TABLE `bloodbank_picture_h`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `convertor`
--
ALTER TABLE `convertor`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `lb_div`
--
ALTER TABLE `lb_div`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;
--
-- AUTO_INCREMENT for table `picture_tips`
--
ALTER TABLE `picture_tips`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `tips`
--
ALTER TABLE `tips`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;
--
-- AUTO_INCREMENT for table `tips_description`
--
ALTER TABLE `tips_description`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `tips_type`
--
ALTER TABLE `tips_type`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
