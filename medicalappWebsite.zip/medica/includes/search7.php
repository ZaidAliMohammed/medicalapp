<?php
$host='localhost';
$user='root';
$password='';
$db='medica';
$con =  mysqli_connect($host,$user,$password,$db);
$db=mysqli_select_db($con,"medica");
$term = strip_tags(substr($_POST['searchit'],0, 100));
$term = mysqli_escape_string($con,$term); // Attack Prevention
if($term=="")
echo "Enter Something to search";
else{
$query = mysqli_query($con,"select title,details,type from tips where type like '{$term}%'");
$string = '';




echo "<table>
<tr>
<th>Title</th>
<th>Details</th>
<th>Type</th>
</tr>";

$rowcount = mysqli_num_rows($query);
echo "Tips Count:"."&nbsp".$rowcount."</br>";



if (mysqli_num_rows($query)){
while($row = mysqli_fetch_assoc($query)){
    echo "<tr>";
    echo "<td>" . $row['title'] . "</td>";
    echo "<td>" . $row['details'] . "</td>";
    echo "<td>" . $row['type'] . "</td>";
    echo "</tr>";
}

}else{
$string = "No matches found!";
}

echo $string;
}
?>