	<?php
	include '../db/db.php';
    $firstname=$_POST['firstname_id'];
	$lastname=$_POST['lastname_id'];
	$age=$_POST['age_id'];
	$contact=$_POST['contact_id'];
	$province=$_POST['province_id'];
    $department=$_POST['department_id'];
    $state=$_POST['state_id'];
    $street=$_POST['street_id'];
	$blood=$_POST['blood_id'];
    $sql=mysqli_query($con,"INSERT INTO bloodbank(firstname, lastname, age, contact, province, department, state, street, blood )VALUES('$firstname', '$lastname', '$age', '$contact', '$province', '$department', '$state', '$street', '$blood')")or die(mysqli_error($con));
   	if($sql){
	$result= 1;
	echo $result;
	}  	
	else{
	$result= 2;
	echo $result;
	}
	
	
?>