	$(document).ready(function() {
		



$("#search_results").slideUp();
$("#search_query1").change(function(event){
event.preventDefault();
search_ajax_way1();
});
$("#search_query1").keyup(function(event){
event.preventDefault();
search_ajax_way1();
});

$("#search_results").slideUp();
$("#search_query2").change(function(event){
event.preventDefault();
search_ajax_way2();
});
$("#search_query2").keyup(function(event){
event.preventDefault();
search_ajax_way2();
});

$("#search_results").slideUp();
$("#search_query3").change(function(event){
event.preventDefault();
search_ajax_way3();
});
$("#search_query3").keyup(function(event){
event.preventDefault();
search_ajax_way3();
});

$("#search_results").slideUp();
$("#search_query4").change(function(event){
event.preventDefault();
search_ajax_way4();
});
$("#search_query4").keyup(function(event){
event.preventDefault();
search_ajax_way4();
});

$("#search_results").slideUp();
$("#search_query5").change(function(event){
event.preventDefault();
search_ajax_way5();
});
$("#search_query5").keyup(function(event){
event.preventDefault();
search_ajax_way5();
});


$("#search_query7").change(function(event){
event.preventDefault();
search_ajax_way7();
});
$("#search_query7").keyup(function(event){
event.preventDefault();
search_ajax_way7();
});






		 		$('#register_id').click(function(){
				
				var firstname=$("#firstname_id").val();
				var lastname=$("#lastname_id").val();
				var age=$("#age_id").val();	
				var contact=$("#contact_id").val();
				var province=$("#province_id").val();
				var department=$("#department_id").val();
				var state=$("#state_id").val();
				var street=$("#street_id").val();
				var blood=$("#blood_id").val();
				var value3=false;
				var value4=false;
				var value5=false;
				var value6=false;
				var value7=false;
				var value8=false;
				var value9=false;
			if(age <=0 || isNaN(age)){$("#age_e").css({"display":"inline"});value3=false;}
				else{$("#age_id").css({"border":"3px solid #A6271C"});value3=true;}	
			if(contact <=0){$("#contact_e").css({"display":"inline"});value4=false;}
				else{$("#contact_id").css({"border":"3px solid #A6271C"});value4=true;}	
			if(province <=0){$("#province_e").css({"display":"inline"});value5=false;}
				else{$("#province_id").css({"border":"3px solid #A6271C"});value5=true;}
			if(department <=0){$("#department_e").css({"display":"inline"});value6=false;}
				else{$("#department_id").css({"border":"3px solid #A6271C"});value6=true;}
			if(state <=0){$("#state_e").css({"display":"inline"});value7=false;}
				else{$("#state_id").css({"border":"3px solid #A6271C"});value7=true;}			
			if(blood <=0){$("#blood_e").css({"display":"inline"});value8=false;}
				else{$("#blood_id").css({"border":"3px solid #A6271C"});value8=true;}
	
					
			if(value3==true &&  value4==true && value5==true &&  value6==true && value7==true &&  value8==true){
			
				
								
		
											
				var d=$("#form_register").serialize();

		$.ajax({	
					url:'includes/register.php',
					type:'post',
					data:d,
					success:function(re){
						if(re==1){
						var boton = "button";
						swal({   
						title: "Successful registration!",  
						html: true ,
						confirmButtonColor: '#A6271C'
						});
						$('#firstname_id').val('');
						$('#lastname_id').val('');
						$('#age_id').val('');	
						$('#contact_id').val('');												
						$('#province_id').val('');
						$('#department_id').val('');	
		                $('#state_id').val('');
					    $('#street_id').val('');
						$('#blood_id').val('');
						}
						

						else if(re==2){
						var boton = "button";
						swal({   
						title: "All fields must be filled!",  
						html: true ,
						confirmButtonColor: '#A6271C'
						});
						$('#firstname_id').val('');
						$('#lastname_id').val('');
						$('#age_id').val('');	
						$('#contact_id').val('');												
						$('#province_id').val('');
						$('#department_id').val('');	
		                $('#state_id').val('');
					    $('#street_id').val('');
						$('#blood_id').val('');
                        }
						
						else{alert (re)}
					},
					error:function(e){alert(e)}
				});				
			}	
	})




	})


	function calculate_m() 
	{ 

				var weight = document.getElementById("weight_id").value; 
				var height =  document.getElementById("height_id").value;
				var height1 = height / 100;
				var heightt = height1 * height1;
				var result = weight / heightt;
				
					if(result < 18.5)
					{			    
						var boton = "button";
						swal({   
							title: "Under Weight!", 
							text: 'Index: ' +result,
							html: true ,
							confirmButtonColor: '#A6271C'
						});
                    }
					else if(result > 18.5 && result < 24.9)
					{		
					var boton = "button";
						swal({   
							title: "Healthy Weight",
							text: 'Index: ' +result,  
							html: true ,
							confirmButtonColor: '#A6271C'
						});
					}
					else if(result > 25 && result < 29.9)
					{
						var boton = "button";
						swal({   
							title: "Over Weight",
							text: 'Index: ' +result,  
							html: true ,
							confirmButtonColor: '#A6271C'
						});  
					}
					else if (result > 30)
					{
						var boton = "button";
						swal({   
							title: "Obese",  
							text: 'Index: ' +result,
							html: true ,
							confirmButtonColor: '#A6271C'
						});
					}
					else 
					{
						var boton = "button";
						swal({   
							title: "Please enter the values!",  
							html: true ,
							confirmButtonColor: '#A6271C'
							
						});
					}

	}
			
			

	function calculate_i() 
	{ 

				var weight = document.getElementById("weight1_id").value; 
				var height =  document.getElementById("height1_id").value;
				var i_to_cm = 2.54 * height;
				var height1 = i_to_cm / 100;
				var heightt = height1 * height1;
				var weightt = weight *  0.453;
				var result = weightt / heightt;
				
					if(result < 18.5)
					{			    
						var boton = "button";
						swal({   
							title: "Under Weight!",
							text: 'Index: ' +result,  
							html: true ,
							confirmButtonColor: '#A6271C'
						});
                    }
					else if(result > 18.5 && result < 24.9)
					{		
					var boton = "button";
						swal({   
							title: "Healthy Weight",  
							text: 'Index: ' +result,
							html: true ,
							confirmButtonColor: '#A6271C'
						});
					}
					else if(result > 25 && result < 29.9)
					{
						var boton = "button";
						swal({   
							title: "Over Weight",
							text: 'Index: ' +result,  
							html: true ,
							confirmButtonColor: '#A6271C'
						});  
					}
					else if (result > 30)
					{
						var boton = "button";
						swal({   
							title: "Obese",
							text: 'Index: ' +result,  
							html: true ,
							confirmButtonColor: '#A6271C'
						});
					}
					else 
					{
						var boton = "button";
						swal({   
							title: "Please enter the values!",  
							html: true ,
							confirmButtonColor: '#A6271C'
							
						});
					}

	}	
	
	
	
	
	
	function convert()
	{ 
			var unit1 = document.getElementById("volume_id1");
			var unit2 = document.getElementById("volume_id2");
			var unit_v1 = unit1.options[unit1.selectedIndex].value;
			var unit_v2 = unit2.options[unit2.selectedIndex].value;
			var from =  document.getElementById("from_txt").value;
			var flo_gal = 0.0078 * from;
			var flo_lit = 0.03 * from;
			var flo_tea = 6 * from;
			var flo_cup = 0.125 * from;
			var gal_fl0 = 128 * from;
			var gal_lit = 3.785 * from;
		    var gal_tea = 768 * from;
			var gal_cup = 16 * from;
			var lit_fl0 = 33.8 * from;
			var lit_gal = 0.264 * from;
		    var lit_tea = 202.9 * from;
			var lit_cup = 4.226* from;
			var tea_fl0 = 0.166 * from;
			var tea_gal = 0.0013 * from;
		    var tea_lit = 0.005 * from;
			var tea_cup = 0.02 * from;
		    var cup_fl0 = 8 * from;
			var cup_gal = 0.062 * from;
		    var cup_lit = 0.236 * from;
			var cup_tea = 48 * from;

			if (unit_v1 == "Fluidounces" && unit_v2 == "Gallons")
			{		
			document.getElementById("to_txt").value = flo_gal;
			}
			else if (unit_v1 == "Fluidounces" && unit_v2 == "Liters")
			{
				document.getElementById("to_txt").value = flo_lit;
			}	
			else if (unit_v1 == "Fluidounces" && unit_v2 == "Teaspoon")
			{
				document.getElementById("to_txt").value = flo_tea;
			}	
			else if (unit_v1 == "Fluidounces" && unit_v2 == "Cups")
			{
				document.getElementById("to_txt").value = flo_cup;
			}
			else if (unit_v1 == "Gallons" && unit_v2 == "Fluidounces")
			{
				document.getElementById("to_txt").value = gal_fl0;
			}	
			else if (unit_v1 == "Gallons" && unit_v2 == "Liters")
			{
				document.getElementById("to_txt").value = gal_lit;
			}	
			else if (unit_v1 == "Gallons" && unit_v2 == "Teaspoon")
			{
				document.getElementById("to_txt").value = gal_tea;
			}
			else if (unit_v1 == "Gallons" && unit_v2 == "Cups")
			{
				document.getElementById("to_txt").value = gal_cup;
			}
			else if (unit_v1 == "Liters" && unit_v2 == "Fluidounces")
			{
				document.getElementById("to_txt").value = lit_fl0;
			}	
			else if (unit_v1 == "Liters" && unit_v2 == "Gallons")
			{
				document.getElementById("to_txt").value = lit_gal;
			}
			else if (unit_v1 == "Liters" && unit_v2 == "Teaspoon")
			{
				document.getElementById("to_txt").value = lit_tea;
			}
			else if (unit_v1 == "Liters" && unit_v2 == "Cups")
			{
				document.getElementById("to_txt").value = lit_cup;
			}
			else if (unit_v1 == "Teaspoon" && unit_v2 == "Fluidounces")
			{
				document.getElementById("to_txt").value = tea_fl0;
			}	
			else if (unit_v1 == "Teaspoon" && unit_v2 == "Gallons")
			{
				document.getElementById("to_txt").value = tea_gal;
			}
			else if (unit_v1 == "Teaspoon" && unit_v2 == "Liters")
			{
				document.getElementById("to_txt").value = tea_lit;
			}
			else if (unit_v1 == "Teaspoon" && unit_v2 == "Cups")
			{
				document.getElementById("to_txt").value = tea_cup;
			}
			else if (unit_v1 == "Cups" && unit_v2 == "Fluidounces")
			{
				document.getElementById("to_txt").value = cup_fl0;
			}	
			else if (unit_v1 == "Cups" && unit_v2 == "Gallons")
			{
				document.getElementById("to_txt").value = cup_gal;
			}
			else if (unit_v1 == "Cups" && unit_v2 == "Liters")
			{
				document.getElementById("to_txt").value = cup_lit;
			}
			else if (unit_v1 == "Cups" && unit_v2 == "Teaspoon")
			{
				document.getElementById("to_txt").value = cup_tea;
			}
			else
			{
				var boton = "button";
						swal({   
							title: "Please enter another unit!",  
							html: true ,
							confirmButtonColor: '#A6271C'
							
						});
			}	
    }		
	
	
	
	
	
	function convert2()
	{ 
			var unit1 = document.getElementById("volume_id12");
			var unit2 = document.getElementById("volume_id22");
			var unit_v1 = unit1.options[unit1.selectedIndex].value;
			var unit_v2 = unit2.options[unit2.selectedIndex].value;
			var from =  document.getElementById("from_txt2").value;
			var cel_fah = ( 1.8 * from ) + 32;
			var fah_cel = ( from - 32 ) * 0.5556;


			if (unit_v1 == "Celsius" && unit_v2 == "Fahrenheit")
			{		
			document.getElementById("to_txt2").value = cel_fah;
			}
			else if (unit_v1 == "Fahrenheit" && unit_v2 == "Celsius")
			{
				document.getElementById("to_txt2").value = fah_cel;
			}	

			else
			{
				var boton = "button";
						swal({   
							title: "Please enter another unit!",  
							html: true ,
							confirmButtonColor: '#A6271C'
							
						});
			}	
    }	
	
	
	
	
	
	
		function convert1()
	{ 
			var unit1 = document.getElementById("volume_id11");
			var unit2 = document.getElementById("volume_id21");
			var unit_v1 = unit1.options[unit1.selectedIndex].value;
			var unit_v2 = unit2.options[unit2.selectedIndex].value;
			var from =  document.getElementById("from_txt1").value;
			var met_inc = from * 39.37;
			var inc_met = 0.0254 * from;


			if (unit_v1 == "Metre" && unit_v2 == "Inch")
			{		
			document.getElementById("to_txt1").value = met_inc;
			
			}
			else if (unit_v1 == "Inch" && unit_v2 == "Metre")
			{
				document.getElementById("to_txt1").value = inc_met;
			}	

			else
			{
				var boton = "button";
						swal({   
							title: "Please enter another unit!",  
							html: true ,
							confirmButtonColor: '#A6271C'
							
						});
			}	
    }	
	
	
	
	
		
			
			
function show(shown, hidden) {
  document.getElementById(shown).style.display='block';
  document.getElementById(hidden).style.display='none';
  return false;
}







function search_ajax_way1(){
$("#search_results").show();
var search_this=$("#search_query1").val();
$.post("includes/search.php", {searchit1 : search_this}, function(data){
$("#display_results").html(data);
})
}


function search_ajax_way2(){
$("#search_results").show();
var search_this=$("#search_query2").val();
$.post("includes/search.php", {searchit2 : search_this}, function(data){
$("#display_results").html(data);
})
}


function search_ajax_way3(){
$("#search_results").show();
var search_this=$("#search_query3").val();
$.post("includes/search.php", {searchit3 : search_this}, function(data){
$("#display_results").html(data);
})
}


function search_ajax_way4(){
$("#search_results").show();
var search_this=$("#search_query4").val();
$.post("includes/search.php", {searchit4 : search_this}, function(data){
$("#display_results").html(data);
})
}


function search_ajax_way5(){
$("#search_results").show();
var search_this=$("#search_query5").val();
$.post("includes/search.php", {searchit5 : search_this}, function(data){
$("#display_results").html(data);
})
}


function search_ajax_way7(){
$("#search_results").show();
var search_this=$("#search_query7").val();
$.post("includes/search7.php", {searchit : search_this}, function(data){
$("#display_results").html(data);
})
}


function validateEmail(email) {var filter = /^[\w\-\.\+]+\@[a-zA-Z0-9\.\-]+\.[a-zA-z0-9]{2,4}$/;if (filter.test(email)){return true;}else {return false;}}





function refer_friend()

{
	 					
				var friendname=$("#friendname_id").val();
				var email=$("#email_id").val();	
				var yourname=$("#yourname_id").val();

				var value1=false;
				var value2=false;
				var value3=false;

			if(friendname <=0 || !isNaN(friendname)){$("#friendname_e").css({"display":"inline"});value1=false;}
				else{$("#friendname_id").css({"border":"3px solid #A6271C"});value1=true;}	
			if(yourname <=0 || !isNaN(yourname)){$("#yourname_e").css({"display":"inline"});value2=false;}
				else{$("#yourname_id").css({"border":"3px solid #A6271C"});value2=true;}	
			if(!validateEmail(email)){$("#email_e").css({"display":"inline"});value3=false;}
				else{$("#email_id").css({"border":"3px solid #A6271C"});value3=true;}
			
			if(value1==true &&  value2==true && value3==true){
											
				var d=$("#form_refer").serialize();

		$.ajax({	
					url:'includes/refer.php',
					type:'post',
					data:d,
					success:function(re){
						if(re==1){
						var boton = "button";
						swal({   
						title: "Successful sending!",  
						html: true ,
						confirmButtonColor: '#A6271C'
						});
						$('#friendname_id').val('');
						$('#email_id').val('');
						$('#yourname_id').val('');	
						}
						
						else if(re==2){
						var boton = "button";
						swal({   
						title: "All fields must be filled!",  
						html: true ,
						confirmButtonColor: '#A6271C'
						});
						$('#friendname_id').val('');
						$('#email_id').val('');
						$('#yourname_id').val('');	
                        }
						
						else{alert (re)}
					},
					error:function(e){alert(e)}
				});				
			}	
	
}




function openNav() {
    document.getElementById("mySidenav").style.width = "250px";
    document.getElementById("main").style.marginLeft = "250px";
}

function closeNav() {
    document.getElementById("mySidenav").style.width = "0";
    document.getElementById("main").style.marginLeft= "0";
}