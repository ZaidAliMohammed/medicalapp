<?php
$host='localhost';
$user='root';
$password='';
$db='medica';
$con =  mysqli_connect($host,$user,$password,$db);
$db=mysqli_select_db($con,"medica");
$term = strip_tags(substr($_POST['searchit'],0, 100));
$term = mysqli_escape_string($con,$term); // Attack Prevention
if($term=="")
echo "Entrez quelque chose à rechercher";
else{
$query = mysqli_query($con,"select contact,age,province,department,state,street,blood from bloodbank where department like '{$term}%'");
$string = '';



echo "<table>
<tr>
<th>Contact</th>
<th>Âge</th>
<th>Province</th>
<th>Département</th>
<th>Etat</th>
<th>Rue</th>
<th>Du sang</th>
</tr>";

$rowcount = mysqli_num_rows($query);
echo "Donors Count:"."&nbsp".$rowcount."</br>";



if (mysqli_num_rows($query)){
while($row = mysqli_fetch_assoc($query)){
   echo "<tr>";
    echo "<td>" . $row['contact'] . "</td>";
    echo "<td>" . $row['age'] . "</td>";
    echo "<td>" . $row['province'] . "</td>";
    echo "<td>" . $row['department'] . "</td>";
    echo "<td>" . $row['state'] . "</td>";
    echo "<td>" . $row['street'] . "</td>";
    echo "<td>" . $row['blood'] . "</td>";
    echo "</tr>";
}

}else{
$string = "Aucun résultat!";
}

echo $string;
}
?>