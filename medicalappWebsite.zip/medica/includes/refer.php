<?php
	include '../db/db.php';
	$friendname=$_POST['friendname_id'];
	$yourname=$_POST['yourname_id'];
    $email2=$_POST['email_id'];
    $sql=mysqli_query($con,"INSERT INTO bloodbank_friends(friendname, yourname, email)VALUES('$friendname', '$yourname', '$email2')")or die(mysqli_error($con));
	
   		if(!$sql){
		echo 2;
		}
		
		else{
			
   $msg="<html>
		<head>
		<title></title>
		<style type='text/css'>
		.spac{ width:400px; height:100px; border:1px solid #FFF; }
		.spac1{ width:400px; height:50px; border:1px solid #FFF; }
		.body_style{width: 500px;  height: 700px;  margin: 0 auto;}
		.content{ border:4px solid #A6271C; border-radius: 10px; box-shadow: 10px 10px 5px #888888; width:500px !important; height:700px !important; margin:0 auto !important; }
		.title{ font-size:36px; font-weight:bold; color:#A6271C; margin:0 auto; text-align:center; margin-top:70px !important; }
		.details{font-size:14px; font-weight:bold; color:#000; margin-left:15px; direction:ltr; text-align:justify;  }
		.indentification{  color:#000;  font-size: 14px; margin-bottom: 40px; margin-top:200px; margin-left:15px;}
		.logo{}
		</style>
		</head>
		<body class='body_style'>
		<div class='content'>
		<div class='title'><p>Invitation for Blood Bank movement by Medica!</p></div>
		<div class='details'>
		<p>Dear $friendname;</p>
		<p>We are reach you via your friend $yourname, help us to save lives</p>
		</div>
		<div class='indentification'>
		<p>Best Regards</p>
		<p style='font-size:16px;'>Medica</p>
		<p>Al Thani Building, 5th floor Beirut, Lebanon</p>			
		<p>Tel/Fax: +961 1 745 751</p>
		<p>Mobile: +961 3 64 64 16</p>
		<p>Email: info@medicarcp.net</p>
		<div class='spac1'></div>
		</div>
		</div>
		</body>
		</html>";
			
				include_once("../includes/class.phpmailer.php");
				$email1="info@medicarcp.net";
				$mail = new phpmailer();
				$mail->IsHTML(true); // if you are going to send HTML formatted emails
				$mail->From =  "info@medicarcp.net";
				$mail->FromName = "Medica";
				$mail->addAddress($email2);
				$mail->Subject = "Invitation!";
				$mail->Body = $msg;				
				if(!$mail->Send())
					$result= "<div class='error_sub'>Message was not sent <br />PHP Mailer Error: " . $mail->ErrorInfo."</div>";
				else
					$result= 1;
				echo $result;
					}

?>