<?php
$host='localhost';
$user='root';
$password='';
$db='medica';
$con =  mysqli_connect($host,$user,$password,$db);
$db=mysqli_select_db($con,"medica");
$term1 = strip_tags(substr($_POST['searchit1'],0, 100));
$term2 = strip_tags(substr($_POST['searchit2'],0, 100));
$term3 = strip_tags(substr($_POST['searchit3'],0, 100));
$term4 = strip_tags(substr($_POST['searchit4'],0, 100));
$term5 = strip_tags(substr($_POST['searchit5'],0, 100));
$term1 = mysqli_escape_string($con,$term1); // Attack Prevention
$term2 = mysqli_escape_string($con,$term2); // Attack Prevention
$term3 = mysqli_escape_string($con,$term3); // Attack Prevention
$term4 = mysqli_escape_string($con,$term4); // Attack Prevention
$term5 = mysqli_escape_string($con,$term5); // Attack Prevention


$query = mysqli_query($con,"select contact,age,province,department,state,street,blood from bloodbank where province like '{$term1}%' and department like '{$term2}%' and state like '{$term3}%' and street like '{$term4}%' and blood like '{$term5}%'");
$string = '';




echo "<table>
<tr>
<th>Contact</th>
<th>Age</th>
<th>Province</th>
<th>Department</th>
<th>State</th>
<th>Street</th>
<th>Blood</th>
</tr>";

$rowcount = mysqli_num_rows($query);
echo "Donors Count:"."&nbsp".$rowcount."</br>";



if (mysqli_num_rows($query)){
while($row = mysqli_fetch_assoc($query)){
   echo "<tr>";
    echo "<td>" . $row['contact'] . "</td>";
    echo "<td>" . $row['age'] . "</td>";
    echo "<td>" . $row['province'] . "</td>";
    echo "<td>" . $row['department'] . "</td>";
    echo "<td>" . $row['state'] . "</td>";
    echo "<td>" . $row['street'] . "</td>";
    echo "<td>" . $row['blood'] . "</td>";
    echo "</tr>";
}

}else{
$string = "No matches found!";
}

echo $string;

?>