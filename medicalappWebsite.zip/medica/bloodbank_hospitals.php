<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<script type="text/javascript" src="lib/jquery.min.js"></script>

<script type="text/javascript" src="includes/jquery-1.11.3.js"></script>

<link rel="stylesheet" type="text/css" href="includes/css.css">

<script type="text/javascript" src="lib/sweetalert.min.js"></script>
<link rel="stylesheet" type="text/css" href="lib/sweetalert.min.css">
<script type="text/javascript" src="includes/js.js"></script>

<title>Blood Bank - Hospitals</title>
</head>

<body>
		  <?php
          include 'db/db.php';
          $sql_description="select hospitals_des from bloodbank_description_h ORDER BY id DESC LIMIT 1 ";
          $res_description=mysqli_query($con,$sql_description);
          $result_description=mysqli_fetch_array($res_description);
		  
		  $sql_picture="select hospitals_pic from bloodbank_picture_h ORDER BY id DESC LIMIT 1 ";
          $res_picture=mysqli_query($con,$sql_picture);
		  $result_picture=mysqli_fetch_array($res_picture);
		  
		  $sql_province="select province from lb_div ORDER BY id ASC ";
          $res_province=mysqli_query($con,$sql_province);
		  
		  $sql_department="select department from lb_div ORDER BY id ASC ";
          $res_department=mysqli_query($con,$sql_department);
		  
		  $sql_state="select state from lb_div ORDER BY id ASC ";
          $res_state=mysqli_query($con,$sql_state);
		  
		  $sql_street="select street from lb_div ORDER BY id ASC ";
          $res_street=mysqli_query($con,$sql_street);
		  
		  $sql_picture_f="select hospitals_pic from bloodbank_f_picture_h ORDER BY id DESC LIMIT 1 ";
          $res_picture_f=mysqli_query($con,$sql_picture_f);
		  $result_picture_f=mysqli_fetch_array($res_picture_f);
		  
		  
          ?>           








<div class="position_reg" >

<div class="space11"></div>

<div class="titl11">Blood Bank (for hospitals)</div>

<div class="space11"></div>


<div class="description">
<div class="paragh">
<?=$result_description['hospitals_des']?>
</div>
</div>

<div class="space11"></div>



<div class="position_l_reg" style=" background-color:#fff">


<form id="form_search" class="alignment_register" name="form_search" method="post"  action="javascript:void(0)">




<div class="textbox_position"><a style="color:#A6271C; font-size:22px; font-weight:bold;">Province:</a>
<div class="new_a1r">
<select class="textbox_properties" name="search_query1" id="search_query1"  style="color:#000000;  background-image:url('icons/arrow.jpg');  -moz-appearance:none;    -webkit-appearance: none;   background-size: auto 100% !important; background-position: 270px !important; cursor:pointer; background-repeat:no-repeat !important;  border:3px solid #A6271C; direction:ltr; font-size:14px; font-family: AddFont; font-family:'Simplified Arabic'; "/>
<option style="background-color:#A6271C; color:#fff;" value=""><span  color:#ffffff;>Select Province</span></option>   

<?php
while($result_province=mysqli_fetch_array($res_province))
{
?>
<option style="background-color:#A6271C; color:#fff;"  value="<?=$result_province['province']?>"><?=$result_province['province']?></option>
<?php
}
?>

</select><img class="error_pic" id="province_e" height="20" width="20" src="icons/error.png" /></div></div>




<div class="textbox_position"><a style="color:#A6271C; font-size:22px; font-weight:bold;"> Department:</a>
<div class="new_a1r">
<select class="textbox_properties" name="search_query2" id="search_query2"  style="color:#000000;  background-image:url('icons/arrow.jpg');  -moz-appearance:none;    -webkit-appearance: none;   background-size: auto 100% !important; background-position: 270px !important; cursor:pointer; background-repeat:no-repeat !important;  border:3px solid #A6271C; direction:ltr; font-size:14px; font-family: AddFont; font-family:'Simplified Arabic'; "/>
<option style="background-color:#A6271C; color:#fff;" value=""><span  color:#ffffff;>Select Department</span></option>

<?php
while($result_department=mysqli_fetch_array($res_department))
{
?>
<option style="background-color:#A6271C; color:#fff;"  value="<?=$result_department['department']?>"><?=$result_department['department']?></option>
<?php
}
?> 
                                                 
</select> 
<img class="error_pic" id="department_e" height="20" width="20" src="icons/error.png" /></div></div>






<div class="textbox_position"><a style="color:#A6271C; font-size:22px; font-weight:bold;">State:</a>
<div class="new_a1r">
<select class="textbox_properties" name="search_query3" id="search_query3"  style="color:#000000;  background-image:url('icons/arrow.jpg');  -moz-appearance:none;    -webkit-appearance: none;   background-size: auto 100% !important; background-position: 270px !important; cursor:pointer; background-repeat:no-repeat !important;  border:3px solid #A6271C; direction:ltr; font-size:14px; font-family: AddFont; font-family:'Simplified Arabic'; "/>
<option style="background-color:#A6271C; color:#fff;" value=""><span  color:#ffffff;>Select State</span></option>

<?php
while($result_state=mysqli_fetch_array($res_state))
{
?>
<option style="background-color:#A6271C; color:#fff;"  value="<?=$result_state['state']?>"><?=$result_state['state']?></option>
<?php
}
?> 

</select>
<img class="error_pic" id="state_e" height="20" width="20" src="icons/error.png" />

</div></div>


 

<div class="textbox_position"><a style="color:#A6271C; font-size:22px; font-weight:bold;">Street:</a>
<div class="new_a1r">
<select class="textbox_properties" name="search_query4" id="search_query4"  style="color:#000000;  background-image:url('icons/arrow.jpg');  -moz-appearance:none;    -webkit-appearance: none;   background-size: auto 100% !important; background-position: 270px !important; cursor:pointer; background-repeat:no-repeat !important;  border:3px solid #A6271C; direction:ltr; font-size:14px; font-family: AddFont; font-family:'Simplified Arabic'; "/>
<option style="background-color:#A6271C; color:#fff;" value=""><span  color:#ffffff;>Select Street</span></option>

<?php
while($result_street=mysqli_fetch_array($res_street))
{
?>
<option style="background-color:#A6271C; color:#fff;"  value="<?=$result_street['street']?>"><?=$result_street['street']?></option>
<?php
}
?> 

</select>
<img class="error_pic" id="street_e" height="20" width="20" src="icons/error.png" />

</div></div>




<div class="textbox_position"><a style="color:#A6271C; font-size:22px; font-weight:bold;">Blood Group:</a>
<div class="new_a1r">
<select class="textbox_properties" name="search_query5" id="search_query5"  style="color:#000000;  background-image:url('icons/arrow.jpg');  -moz-appearance:none;    -webkit-appearance: none;   background-size: auto 100% !important; background-position: 270px !important; cursor:pointer; background-repeat:no-repeat !important;  border:3px solid #A6271C; direction:ltr; font-size:14px; font-family: AddFont; font-family:'Simplified Arabic'; "/>
<option style="background-color:#A6271C; color:#fff;" value=""><span  color:#ffffff;>Select Type</span></option>
<option style="background-color:#A6271C; color:#fff;" value="A+">A+</option>
<option style="background-color:#A6271C; color:#fff;" value="A-">A-</option>
<option style="background-color:#A6271C; color:#fff;" value="B+">B+</option>
<option style="background-color:#A6271C; color:#fff;" value="B-">B-</option>
<option style="background-color:#A6271C; color:#fff;" value="AB+">AB+</option>
<option style="background-color:#A6271C; color:#fff;" value="AB-">AB-</option>
<option style="background-color:#A6271C; color:#fff;" value="O+">O+</option>
<option style="background-color:#A6271C; color:#fff;" value="O-">O-</option>
</select><img class="error_pic" id="blood_e" height="20" width="20" src="icons/error.png" /></div></div>







</form> 

</div>






  
<div  class="position_r_reg">
<img src="uploads/<?=$result_picture['hospitals_pic']?>" width="300" height="300" />
</div>  



<div class="space11"></div>
<div class="position_s1">
<div id="display_results"></div>
</div>
<div class="space11"></div>



<div  class="position_s">
<img src="uploads/<?=$result_picture_f['hospitals_pic']?>" width="1000" height="200" />
</div>

</div>
  

  
  
  




</div>  
  
  


</body>
</html>