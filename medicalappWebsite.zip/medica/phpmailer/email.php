<?php
session_start();
require 'class.phpmailer.php';
$mail = new phpmailer();
$mail->PluginDir = './'; // relative path to the folder where PHPMailer's files are located
$mail->IsSMTP();
$mail->Port = 465;
$mail->Host = 'smtp.gmail.com'; // "ssl://smtp.gmail.com" didn't worked
$mail->IsHTML(true); // if you are going to send HTML formatted emails
$mail->Mailer = 'smtp';
$mail->SMTPSecure = 'ssl';

$mail->SMTPAuth = true;
$mail->Username = "alihghaith@gmail.com";
$mail->Password = "**20190pajalousta**";

$mail->SingleTo = true; // if you want to send mail to the users individually so that no recipients can see that who has got the same email.

$mail->From = "alihghaith@gmail.com";
$mail->FromName = "Fitness Zone";

$mail->addAddress("virtuelomega@hotmail.com","User 1");
$email='virtuelomega@hotmail.com';
//$mail->addAddress("user.2@gmail.com","User 2");

//$mail->addCC("user.3@ymail.com","User 3");
//$mail->addBCC("user.4@in.com","User 4");


$mail->Subject = "Signup | Verification";
$mail->Body = $_SESSION['message'];


if(!$mail->Send())
    echo "Message was not sent <br />PHP Mailer Error: " . $mail->ErrorInfo;
else
    echo "Message has been sent";
	
	
	              
	
	
	
	
?>