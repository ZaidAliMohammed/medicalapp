<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<script type="text/javascript" src="lib/jquery.min.js"></script>

<script type="text/javascript" src="includes/jquery-1.11.3.js"></script>

<link rel="stylesheet" type="text/css" href="includes/css.css">

<script type="text/javascript" src="lib/sweetalert.min.js"></script>
<link rel="stylesheet" type="text/css" href="lib/sweetalert.min.css">
<script type="text/javascript" src="includes/js.js"></script>

<title>Grandmother Tips</title>
</head>

<body>
		  <?php
          include 'db/db.php';
          $sql_description="select tips_des from tips_description ORDER BY id DESC LIMIT 1 ";
          $res_description=mysqli_query($con,$sql_description);
          $result_description=mysqli_fetch_array($res_description);
		  
		  $sql_picture_t="select tips_pic from picture_tips ORDER BY id DESC LIMIT 1 ";
          $res_picture_t=mysqli_query($con,$sql_picture_t);
		  $result_picture_t=mysqli_fetch_array($res_picture_t);
		  
		  $sql_province="select province from lb_div ORDER BY id ASC ";
          $res_province=mysqli_query($con,$sql_province);
		  
		  $sql_department="select department from lb_div ORDER BY id ASC ";
          $res_department=mysqli_query($con,$sql_department);
		  
		  $sql_state="select state from lb_div ORDER BY id ASC ";
          $res_state=mysqli_query($con,$sql_state);
		  
		  $sql_street="select street from lb_div ORDER BY id ASC ";
          $res_street=mysqli_query($con,$sql_street);
		  
		  $sql_picture_f="select hospitals_pic from bloodbank_f_picture_h ORDER BY id DESC LIMIT 1 ";
          $res_picture_f=mysqli_query($con,$sql_picture_f);
		  $result_picture_f=mysqli_fetch_array($res_picture_f);
		  
		  $sql_tt="select type from tips_type ORDER BY id ASC ";
          $res_tt=mysqli_query($con,$sql_tt);
		  
		  $sql_tips="select * from tips  order by id asc";
          $res_tips=mysqli_query($con,$sql_tips);
          ?>           









<div class="position_reg" >

<div class="space11"></div>

<div class="titl11">Grandmother Tips</div>

<div class="space11"></div>


<div class="description">
<div class="paragh">
<?=$result_description['tips_des']?>
</div>
</div>

<div class="space11"></div>





<div class="url_tips">For Search press <a href="tips_search.php"> here:</a> </div>
<div class="space11"></div>

		   <?php
          while($result_tips=mysqli_fetch_array($res_tips))
          { ?> 



<nav class="nav">
    <ul>
        <li>
            <a href="#" style="text-decoration:none; color:#A6271C; font-size:26px; font-weight:bold;"><?=$result_tips['title']?></a>
            <ul>
<div class="specific"><p style="width:990px;"><?=$result_tips['details']?></p></div>
            </ul>
        </li>
        
    </ul>
    <div style="height:15px; " ></div>
    
</nav>

<?php } ?><br>






<div class="space11"></div>
<div class="position_s1">
<div id="display_results"></div>
</div>
<div class="space11"></div>




</div>
  

  
  
  




</div>  
  
  


</body>
</html>