<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<script type="text/javascript" src="lib/jquery.min.js"></script>

<script type="text/javascript" src="includes/jquery-1.11.3.js"></script>

<link rel="stylesheet" type="text/css" href="includes/css.css">

<script type="text/javascript" src="lib/sweetalert.min.js"></script>
<link rel="stylesheet" type="text/css" href="lib/sweetalert.min.css">
<script type="text/javascript" src="includes/js.js"></script>

<title>Convertor</title>
</head>

<body>

<div class="position" >
<div class="space11"></div>
<div class="space11"></div>
<div class="space11"></div>
<div class="position_l_con" style=" background-color:#fff">

<div class="space11"></div>

<div class="titl11">Unit Converters</div>


<div id="mySidenav" class="sidenav">
  <a href="javascript:void(0)" class="closebtn" onclick="closeNav()">&times;</a>
  <a href="temperature.php">Temperature</a>
  <a href="length.php">Length</a>
  <a href="volume.php">Volume</a>
</div>
<div id="main" style=" margin-top:50px; ">
  <span style="font-size:30px;color:#A6271C;cursor:pointer" onclick="openNav()">&#9776; Choose convertor</span>
</div>

     
</div>
</div>     
     
     
     
</body>
</html> 