<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />

<script  type="text/javascript" src="includes/js.js"></script>
<link rel="stylesheet" type="text/css" href="includes/css.css">

<script type="text/javascript" src="lib/sweetalert.min.js"></script>
<link rel="stylesheet" type="text/css" href="lib/sweetalert.min.css">
<title>Convertor</title>
</head>

<body>


			  <!-------------------unit conversation-------------------->
              <b class="m2">  Unit Conversion</b>
			  <div class="conversion_home">
			  <div class="r1">
			  
              
              <b class="m3">Volume:</b>
			  <form id="Conversion" name="form" method="post" action="javascript:void(0)">
			  <div class="R3">
			  
			  <div class="unit">
			  <input class="center_home" type="text" name="from" id="from_txt" size="12" />
			  <select class="R6" id="volume_id1" style="background-image:url('icons/arrow.jpg');  -moz-appearance:none;    -webkit-appearance: none;   background-size: auto 100% !important; background-position: 97px !important; cursor:pointer; background-repeat:no-repeat !important;" >
              <option style="background-color:#A6271C; color:#fff;" value="Fluidounces">Fluid ounce</option>
              <option style="background-color:#A6271C; color:#fff;"   value="Gallons">Gallon</option>
              <option style="background-color:#A6271C; color:#fff;"    value="Liters">Liter</option>
              <option style="background-color:#A6271C; color:#fff;"    value="Teaspoon">Tea spoon</option>
			  <option style="background-color:#A6271C; color:#fff;"   value="Cups">Cup</option>
              </select>
			  
			  </div>
			  </div>
			  <div class="R2_eq"><b>=</b></div>
			  <div class="R3">
			  
			  <div class="unit1">
			  <input class="center_home" type="text" name="to" id="to_txt"  size="12" />
			  <select class="R6" id="volume_id2" style="background-image:url('icons/arrow.jpg');  -moz-appearance:none;    -webkit-appearance: none;   background-size: auto 100% !important; background-position: 97px !important; cursor:pointer; background-repeat:no-repeat !important;">
              <option style="background-color:#A6271C; color:#fff;"  value="Fluidounces">Fluid ounce</option>
              <option style="background-color:#A6271C; color:#fff;"  value="Gallons">Gallon</option>
              <option style="background-color:#A6271C; color:#fff;"  value="Liters">Liter</option>
              <option style="background-color:#A6271C; color:#fff;"  value="Teaspoon">Tea spoon</option>
			  <option style="background-color:#A6271C; color:#fff;"  value="Cups">Cup</option>
              </select>
						<input class="submit_style_reg1" style="cursor:pointer;  border:3px solid #A6271C; font-size:20px; font-family: AddFont;     height: 28px; font-family:'Times New Roman', Times, serif;" type="submit" name="volume_id" id="volume_id" value="Convert" onclick="convert()"/>

			  </div>
			  </div>
	  		  </form>
              
              
              
              
              <b class="m3">Length:</b>
			  <form id="Conversion" name="form1" method="post" action="javascript:void(0)">
			  <div class="R3">
			  
			  <div class="unit">
			  <input class="center_home" type="text" name="from_txt1" id="from_txt1" size="12"/>
			  <select class="R6" id="volume_id11" style="background-image:url('icons/arrow.jpg');  -moz-appearance:none;    -webkit-appearance: none;   background-size: auto 100% !important; background-position: 97px !important; cursor:pointer; background-repeat:no-repeat !important;" >
              <option style="background-color:#A6271C; color:#fff;"  value="Metre">Metre</option>
              <option style="background-color:#A6271C; color:#fff;"  value="Inch">Inch</option>
              </select>
			  
			  </div>
			  </div>
			  <div class="R2_eq"><b>=</b></div>
			  <div class="R3">
			  
			  <div class="unit1">
			  <input class="center_home" type="text" name="to_txt1" id="to_txt1"  size="12" />
			  <select class="R6" id="volume_id21" style="background-image:url('icons/arrow.jpg');  -moz-appearance:none;    -webkit-appearance: none;   background-size: auto 100% !important; background-position: 97px !important; cursor:pointer; background-repeat:no-repeat !important;" >
              <option style="background-color:#A6271C; color:#fff;"  value="Metre">Metre</option>
              <option style="background-color:#A6271C; color:#fff;"  value="Inch">Inch</option>

              </select>
			<input class="submit_style_reg1" style="cursor:pointer;  border:3px solid #A6271C; font-size:20px; font-family: AddFont;     height: 28px; font-family:'Times New Roman', Times, serif;" type="submit" name="length_id" id="length_id" value="Convert" onclick="convert1()"/>
			  </div>
			  </div>
	  		  </form>
              
              
              
              
              
              <b class="m3">Temprature:</b>
			  <form id="Conversion2" name="form2" method="post" action="javascript:void(0)">
			  <div class="R3">
			  
			  <div class="unit">
			  <input class="center_home" type="text" name="from2" id="from_txt2" size="12" />
			  <select class="R6" id="volume_id12"  style="background-image:url('icons/arrow.jpg');  -moz-appearance:none;    -webkit-appearance: none;   background-size: auto 100% !important; background-position: 97px !important; cursor:pointer; background-repeat:no-repeat !important;">
              <option style="background-color:#A6271C; color:#fff;" value="Celsius">Celsius</option>
              <option style="background-color:#A6271C; color:#fff;"  value="Fahrenheit">Fahrenheit</option>

              </select>
			  
			  </div>
			  </div>
			  <div class="R2_eq"><b>=</b></div>
			  <div class="R3">
			  
			  <div class="unit1">
			  <input class="center_home" type="text" name="to2" id="to_txt2"  size="12" />
			  <select class="R6" id="volume_id22" style="background-image:url('icons/arrow.jpg');  -moz-appearance:none;    -webkit-appearance: none;   background-size: auto 100% !important; background-position: 97px !important; cursor:pointer; background-repeat:no-repeat !important;">
              <option style="background-color:#A6271C; color:#fff;" value="Celsius">Celsius</option>
              <option style="background-color:#A6271C; color:#fff;"  value="Fahrenheit">Fahrenheit</option>

              </select>
			<input class="submit_style_reg1" style="cursor:pointer;  border:3px solid #A6271C; font-size:20px; font-family: AddFont;     height: 28px; font-family:'Times New Roman', Times, serif;" type="submit" name="temprature_id" id="temprature_id" value="Convert" onclick="convert2()"/>

			  </div>
			  </div>
	  		  </form>
              
                            
			  </div>
			  </div>



</body>
</html>