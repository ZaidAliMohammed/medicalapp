<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<script type="text/javascript" src="lib/jquery.min.js"></script>

<script type="text/javascript" src="includes/jquery-1.11.3.js"></script>

<link rel="stylesheet" type="text/css" href="includes/css.css">

<script type="text/javascript" src="lib/sweetalert.min.js"></script>
<link rel="stylesheet" type="text/css" href="lib/sweetalert.min.css">
<script type="text/javascript" src="includes/js.js"></script>

<title>Length Converter</title>
</head>
<body>
		  <?php
          include 'db/db.php';
		  $sql_picture_con="select con_pic from convertor ORDER BY id DESC LIMIT 3 ";
          $res_picture_con=mysqli_query($con,$sql_picture_con);
          ?>


<div class="position" >
<div class="space11"></div>
<div class="titl11"></div>
<div class="space11"></div>
<div class="space11"></div>
<div class="position_l_con" style=" background-color:#fff">


			  <div class="conversion_home">



              <b class="m3">Length:</b>
			  <form id="Conversion" name="form1" method="post" action="javascript:void(0)">
			  <div class="R3">
			  
			  <div class="unit">
			  <input class="center_home" type="text" name="from_txt1" id="from_txt1" size="12"/>
			  <select class="R6" id="volume_id11" style="background-image:url('icons/arrow.jpg');  -moz-appearance:none;    -webkit-appearance: none;   background-size: auto 100% !important; background-position: 97px !important; cursor:pointer; background-repeat:no-repeat !important;" >
              <option style="background-color:#A6271C; color:#fff;"  value="Metre">Metre</option>
              <option style="background-color:#A6271C; color:#fff;"  value="Inch">Inch</option>
              </select>
			  
			  </div>
			  </div>
			  <div class="R2_eq"><b>=</b></div>
			  <div class="R3">
			  
			  <div class="unit1">
			  <input class="center_home" type="text" name="to_txt1" id="to_txt1"  size="12" />
			  <select class="R6" id="volume_id21" style="background-image:url('icons/arrow.jpg');  -moz-appearance:none;    -webkit-appearance: none;   background-size: auto 100% !important; background-position: 97px !important; cursor:pointer; background-repeat:no-repeat !important;" >
              <option style="background-color:#A6271C; color:#fff;"  value="Metre">Metre</option>
              <option style="background-color:#A6271C; color:#fff;"  value="Inch">Inch</option>

              </select>
			<input class="submit_style_reg1" style="cursor:pointer;  border:3px solid #A6271C; font-size:20px; font-family: AddFont;     height: 28px; font-family:'Times New Roman', Times, serif;" type="submit" name="length_id" id="length_id" value="Convert" onclick="convert1()"/>
			  </div>
			  </div>
	  		  </form>
</div>

</div>
<div  class="position_r">
<?php
while($result_picture_con=mysqli_fetch_array($res_picture_con))
{
?>


<img src="uploads/<?=$result_picture_con['con_pic']?>" width="150" height="150" />

<?php
}
?>
</div>
</div>  
</body>
</html>